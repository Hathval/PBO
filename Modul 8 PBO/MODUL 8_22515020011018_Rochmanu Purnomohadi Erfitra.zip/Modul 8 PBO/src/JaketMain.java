public class JaketMain {
    public static void main(String[] args) {
        Jaket jaket = new Jaket();

        jaket.katalog();
        jaket.print();

        
    }
    
}
