interface Pembayaran {
    int getTotalPembayaran(); 
}